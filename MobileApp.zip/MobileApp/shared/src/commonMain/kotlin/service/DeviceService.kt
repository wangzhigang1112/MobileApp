package service

/**
 * 作者： 王志刚
 * 创建时间： 2023/8/24 21:34
 * 版本： [1.0, 2023/8/24]
 * 版权： 国泰新点软件股份有限公司
 * 描述： <描述>
 */
/**
 * 获取设备相关service
 */
expect object DeviceService {

    /**
     * 获取底部安全区域高度
     */
    fun getBottomSafeAreaHeight(): Double

}
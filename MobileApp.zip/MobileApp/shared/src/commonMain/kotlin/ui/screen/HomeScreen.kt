package ui.screen

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import service.DeviceService
import ui.widgets.PageItem

/**
 * 作者： 王志刚
 * 创建时间： 2023/8/24 20:57
 * 版本： [1.0, 2023/8/24]
 * 版权： 国泰新点软件股份有限公司
 * 描述： <描述>
 */
//class HomeScreen {
//}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen() {
    HorizontalPager(
        pageCount = 3,
        contentPadding = PaddingValues(
            start = 32.dp,
            top = 32.dp,
            end = 32.dp,
            bottom = DeviceService.getBottomSafeAreaHeight().dp + 32.dp

        ),
        pageSpacing = 16.dp
    ) { index ->
        PageItem(
            "今日的一句话",
            "王若晨",
            "2023-08-31",
            "星期四",
            "http://photo.16pic.com/00/92/37/16pic_9237857_b.jpg"
        )
    }
}
package service

/**
 * 获取设备相关service
 */
actual object DeviceService {
    /**
     * 获取底部安全区域高度
     */
    actual fun getBottomSafeAreaHeight(): Double {
        return 0.0
    }

}
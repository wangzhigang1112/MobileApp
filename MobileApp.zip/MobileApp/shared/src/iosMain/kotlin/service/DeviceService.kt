package service

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import platform.UIKit.UIApplication
import platform.UIKit.UIWindow
import platform.UIKit.UIWindowScene

/**
 * 获取设备相关service
 */
actual object DeviceService {
    /**
     * 获取底部安全区域高度
     */
    @OptIn(ExperimentalForeignApi::class)
    actual fun getBottomSafeAreaHeight(): Double {
        val scene = UIApplication.sharedApplication.connectedScenes.first() as UIWindowScene
        val window = scene.windows.first() as UIWindow
        window.safeAreaInsets.useContents {
            return this.bottom
        }
    }

}